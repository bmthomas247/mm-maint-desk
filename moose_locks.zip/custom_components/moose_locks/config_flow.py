"""One click: Settings > Devices & services > Add integration > Moose Locks. No questions asked."""
import secrets

from homeassistant import config_entries

from .const import DOMAIN


class MooseLocksFlow(config_entries.ConfigFlow, domain=DOMAIN):
    VERSION = 1

    async def async_step_user(self, user_input=None):
        await self.async_set_unique_id(DOMAIN)
        self._abort_if_unique_id_configured()
        if user_input is None and not self._async_current_entries():
            return self.async_show_form(step_id="user")
        return self.async_create_entry(
            title="Moose Locks",
            data={"secret": secrets.token_urlsafe(48), "fingerprint": None},
        )
