"""Moose Locks hub logic.

Runs inside Home Assistant on each home's hub. It opens its OWN connection to the Z-Wave JS server
(the same one Home Assistant uses), so it doesn't depend on Home Assistant internals.

Every 30 seconds (or right away when the server sends a "wake" ping) it:
  1. reports the locks it sees (battery, online, locked/unlocked), what happened at the doors, and results
  2. gets back the codes each lock should hold (slot -> code) and any commands (unlock, add lock, ...)
  3. writes each code, READS IT BACK from the lock, and only then reports it "verified"
Codes live on the lock itself, so they keep working if the internet or this hub goes down.
"""
from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timezone

import aiohttp

from homeassistant.components import persistent_notification
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.dispatcher import async_dispatcher_send

from zwave_js_server.client import Client as ZClient
from zwave_js_server.const import CommandClass, InclusionStrategy
from zwave_js_server.model.controller import InclusionGrant
from zwave_js_server.util.lock import (
    clear_usercode,
    get_usercode_from_node,
    get_usercodes,
    set_usercode,
)

from .const import (
    ACCESS_EVENTS, ANON_KEY, API_URL, CC_BATTERY, CC_BINARY_SENSOR, CC_DOOR_LOCK, CC_LOCK,
    CC_NOTIFICATION, CC_SCHEDULE_ENTRY_LOCK, CC_SENSOR_MULTILEVEL, CC_TIME_PARAMETERS, CC_THERMOSTAT_MODE, CC_THERMOSTAT_SETPOINT, CC_USER_CODE,
    DOMAIN, MAX_BACKOFF, POLL_SECONDS, THERMO_MODE_IDS, THERMO_MODES, VERSION, WATER_EVENTS,
)

_LOG = logging.getLogger(__name__)
SIGNAL = f"{DOMAIN}_update"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class MooseHub:
    def __init__(self, hass: HomeAssistant, entry) -> None:
        self.hass = hass
        self.entry = entry
        self.session = async_get_clientsession(hass)
        self.zclient: ZClient | None = None
        self._zlisten: asyncio.Task | None = None
        self._tasks: list[asyncio.Task] = []
        self._wake = asyncio.Event()
        self._zlock = asyncio.Lock()            # one Z-Wave job at a time
        self._unsubs: list = []
        self.events: list[dict] = []            # waiting to be sent
        self.results: dict[int, dict] = {}      # assignment id -> result waiting to be sent
        self.cmd_results: list[dict] = []
        self.audits: list[dict] = []
        self.attempts: dict[int, tuple[float, int]] = {}   # assignment id -> (last try, tries)
        self.last_audit: str | None = None
        self.realtime: dict | None = None
        self.state = "starting"
        self.pair_code: str | None = None
        self.property_id: str | None = None
        self.lock_names: dict[int, str] = {}
        self.including: dict | None = None      # {"pin":..., "cmd":..., "until":...}
        self.excluding: dict | None = None
        self.last_ok: float = 0
        self.started: float = time.time()
        self.governor: dict = {}
        self.clock_checked: dict[int, str] = {}       # node id -> day we last set its clock / time zone
        self.update_results: list[dict] = []          # updates started / failed, waiting to be sent
        self.updating: str | None = None              # entity being installed right now (one at a time)

    # ------------------------------------------------------------------ lifecycle
    async def start(self) -> None:
        self._tasks.append(asyncio.create_task(self._run()))

    async def stop(self) -> None:
        for t in self._tasks:
            t.cancel()
        for u in self._unsubs:
            try:
                u()
            except Exception:  # noqa: BLE001
                pass
        if self.zclient:
            await self.zclient.disconnect()
        if self._zlisten:
            self._zlisten.cancel()

    def _set_state(self, state: str) -> None:
        self.state = state
        async_dispatcher_send(self.hass, SIGNAL)

    # ------------------------------------------------------------------ Z-Wave connection
    async def _zwave(self) -> None:
        if self.zclient and self.zclient.connected and self.zclient.driver:
            return
        entries = self.hass.config_entries.async_entries("zwave_js")
        if not entries:
            raise RuntimeError("Z-Wave JS isn't set up on this hub")
        url = entries[0].data.get("url") or "ws://core-zwave-js:3000"
        self.zclient = ZClient(url, self.session, additional_user_agent_components={"moose_locks": VERSION})
        await self.zclient.connect()
        ready = asyncio.Event()
        self._zlisten = asyncio.create_task(self.zclient.listen(ready))
        await asyncio.wait_for(ready.wait(), 120)
        ctl = self.zclient.driver.controller
        for node in ctl.nodes.values():
            self._watch(node)
        self._unsubs.append(ctl.on("node added", self._on_node_added))
        self._unsubs.append(ctl.on("node removed", self._on_node_removed))
        self._unsubs.append(ctl.on("grant security classes", self._on_grant))
        self._unsubs.append(ctl.on("validate dsk and enter pin", self._on_dsk))
        self._unsubs.append(ctl.on("inclusion failed", lambda e: self._incl_done(False, "pairing failed")))
        self._unsubs.append(ctl.on("inclusion stopped", lambda e: self._incl_done(None, "pairing stopped")))
        self._unsubs.append(ctl.on("exclusion stopped", lambda e: self._excl_done(None, "remove stopped")))
        await self._fingerprint(ctl.home_id)

    async def _fingerprint(self, home_id) -> None:
        """A hub restored from our backup image gets its own identity (new secret) the first time it runs."""
        fp = str(home_id or "")
        old = self.entry.data.get("fingerprint")
        if old == fp:
            return
        data = dict(self.entry.data)
        if old:   # a different Z-Wave stick than the one this secret was made with -> new hub
            import secrets
            data["secret"] = secrets.token_urlsafe(48)
            data.pop("registered", None)
        data["fingerprint"] = fp
        self.hass.config_entries.async_update_entry(self.entry, data=data)

    @staticmethod
    def _is_lock(node) -> bool:
        if node.is_controller_node:
            return False
        return any(v.command_class in (CC_DOOR_LOCK, CC_LOCK) for v in node.values.values())

    @staticmethod
    def _kind(node) -> str | None:
        """lock / thermostat / leak / contact / None"""
        if node.is_controller_node:
            return None
        ccs = {v.command_class for v in node.values.values()}
        if ccs & {CC_DOOR_LOCK, CC_LOCK}:
            return "lock"
        if ccs & {CC_THERMOSTAT_MODE, CC_THERMOSTAT_SETPOINT}:
            return "thermostat"
        props = {str(v.property_) for v in node.values.values() if v.command_class == CC_NOTIFICATION}
        if "Water Alarm" in props:
            return "leak"
        if "Access Control" in props or CC_BINARY_SENSOR in ccs:
            return "contact"
        return None

    def _watch(self, node) -> None:
        if not self._kind(node):
            return
        self._unsubs.append(node.on("notification", lambda e, n=node: self._on_notification(n, e)))
        if self._kind(node) == "thermostat":
            self._unsubs.append(node.on("value updated", lambda e, n=node: self._on_value(n, e)))

    def _on_value(self, node, event) -> None:
        """Governor: a guest set the thermostat past the limits -> snap it back right away."""
        args = event.get("args") or {}
        if args.get("commandClass") == CC_THERMOSTAT_SETPOINT and args.get("property") == "setpoint":
            asyncio.create_task(self._govern(node))

    def _on_node_added(self, event) -> None:
        node = event["node"]
        self._watch(node)
        if self.including:
            self._incl_done(True, f"lock added as node {node.node_id}", node.node_id)

    def _on_node_removed(self, event) -> None:
        node = event["node"]
        self.events.append({"at": _now(), "node_id": node.node_id, "kind": "lock_removed"})
        self._excl_done(True, f"node {node.node_id} removed", node.node_id)

    def _on_notification(self, node, event) -> None:
        n = event.get("notification")
        ntype = getattr(n, "type_", None)
        if ntype == 6:                               # Access Control: locks + door sensors
            kind = ACCESS_EVENTS.get(getattr(n, "event", None))
        elif ntype == 5:                             # Water Alarm: leak sensors
            kind = WATER_EVENTS.get(getattr(n, "event", None))
        else:
            return
        if not kind:
            return
        params = getattr(n, "parameters", None) or {}
        slot = params.get("userId") if isinstance(params, dict) else None
        self.events.append({"at": _now(), "node_id": node.node_id, "kind": kind, "slot": slot,
                            "detail": {"label": getattr(n, "event_label", "")}})
        self._wake.set()

    # ------------------------------------------------------------------ pairing a lock (S2 PIN from the module's sticker)
    async def _on_grant(self, event) -> None:
        if not self.including:
            return
        req = event.get("requested")
        grant = InclusionGrant.from_dict(req) if isinstance(req, dict) else event.get("requested_grant")
        await self.zclient.driver.controller.async_grant_security_classes(InclusionGrant(grant.security_classes, False))

    async def _on_dsk(self, event) -> None:
        if not self.including:
            return
        pin = str(self.including.get("pin") or "")
        if len(pin) != 5:
            self._incl_done(False, "type the 5-digit PIN from the sticker on the lock's Z-Wave module")
            await self.zclient.driver.controller.async_stop_inclusion()
            return
        await self.zclient.driver.controller.async_validate_dsk_and_enter_pin(pin)

    def _incl_done(self, ok, msg, node_id=None) -> None:
        if not self.including:
            return
        if ok is None and self.including.get("done"):
            return
        self.cmd_results.append({"id": self.including["cmd"], "ok": bool(ok), "result": {"msg": msg, "node_id": node_id}})
        self.including = None
        if ok and node_id:
            self._audit_soon = True
        self._wake.set()

    def _excl_done(self, ok, msg, node_id=None) -> None:
        if not self.excluding:
            return
        self.cmd_results.append({"id": self.excluding["cmd"], "ok": bool(ok), "result": {"msg": msg, "node_id": node_id}})
        self.excluding = None
        self._wake.set()

    # ------------------------------------------------------------------ main loop
    async def _run(self) -> None:
        backoff = 5
        self._audit_soon = False
        while True:
            try:
                await self._zwave()
                await self._register()
                self._tasks.append(asyncio.create_task(self._realtime()))
                break
            except Exception as e:  # noqa: BLE001
                _LOG.warning("Moose Locks starting: %s", e)
                self._set_state(f"starting: {e}")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 300)
        while True:
            try:
                await self._zwave()
                await self._sync_once()
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                _LOG.warning("Moose Locks sync: %s", e)
                self._set_state(f"error: {e}")
            try:
                await asyncio.wait_for(self._wake.wait(), POLL_SECONDS)
            except asyncio.TimeoutError:
                pass
            self._wake.clear()

    async def _api(self, action: str, body: dict) -> dict:
        headers = {"apikey": ANON_KEY, "content-type": "application/json"}
        if not ANON_KEY.startswith("sb_"):
            headers["authorization"] = "Bearer " + ANON_KEY
        payload = {"p_secret": self.entry.data["secret"], "p_action": action, "p": body.get("payload", body)}
        async with self.session.post(API_URL, json=payload, headers=headers,
                                     timeout=aiohttp.ClientTimeout(total=30)) as r:
            data = await r.json(content_type=None)
            if r.status >= 300 or (isinstance(data, dict) and data.get("error")):
                raise RuntimeError(f"server {r.status}: {data}")
            return data

    async def _register(self) -> None:
        home_id = self.zclient.driver.controller.home_id
        res = await self._api("register", {"fingerprint": str(home_id), "version": VERSION})
        self.pair_code = res.get("pair_code")
        if not res.get("claimed"):
            persistent_notification.async_create(
                self.hass,
                f"Open the Moose lock setup page on your phone (on this home's Wi-Fi) and tap **Find hub**.\n\n"
                f"If it doesn't show up, type this code: **{self.pair_code}**",
                title="Moose Locks: add this hub to a home", notification_id="moose_locks_pair")

    # ------------------------------------------------------------------ one sync round trip
    def _locks_report(self) -> list[dict]:
        out = []
        for node in self.zclient.driver.controller.nodes.values():
            if not self._is_lock(node):
                continue
            battery = state = None
            slots = used = 0
            for v in node.values.values():
                if v.command_class == CC_USER_CODE and v.property_ == "userIdStatus":
                    slots += 1                                   # one per code slot the lock has
                    if v.value in (1, 2):                        # 1 = in use, 2 = in use but turned off
                        used += 1
                if v.command_class == CC_BATTERY and v.property_ == "level":
                    battery = v.value
                elif v.command_class == CC_DOOR_LOCK and v.property_ == "currentMode":
                    state = "locked" if v.value == 255 else ("unlocked" if v.value is not None else None)
                elif v.command_class == CC_LOCK and v.property_ == "locked" and state is None:
                    state = "locked" if v.value else ("unlocked" if v.value is not None else None)
            status = getattr(node.status, "name", str(node.status)).lower()
            model = " ".join(x for x in [node.device_config.manufacturer if node.device_config else None,
                                         node.device_config.label if node.device_config else None] if x)
            out.append({"node_id": node.node_id, "model": model or None, "battery": battery,
                        "online": status != "dead", "state": state, "slots": slots or None, "slots_used": used if slots else None,
                        **self._stats(node)})
        return out

    @staticmethod
    def _f(v) -> float | None:
        """value -> Fahrenheit (thermostats may report C)"""
        if v is None or v.value is None:
            return None
        unit = (getattr(v.metadata, "unit", "") or "").upper()
        return round(v.value * 9 / 5 + 32, 1) if "C" in unit and "F" not in unit else v.value

    @staticmethod
    def _stats(node) -> dict:
        """signal strength + reliability for the installer tools"""
        try:
            st = node.statistics
            return {"rssi": st.rssi, "rtt": st.rtt,
                    "dropped": (st.commands_dropped_rx or 0) + (st.commands_dropped_tx or 0) + (st.timeout_response or 0)}
        except Exception:  # noqa: BLE001
            return {}

    def _hub_info(self) -> dict:
        from homeassistant.const import __version__ as ha_version
        ctl = self.zclient.driver.controller
        return {"version": VERSION, "ha": ha_version, "zwave_fw": getattr(ctl, "firmware_version", None),
                "zwave_sdk": getattr(ctl, "sdk_version", None), "home_id": str(ctl.home_id),
                "uptime_min": int((time.time() - self.started) / 60), "nodes": len(ctl.nodes)}

    def _devices_report(self) -> tuple[list[dict], list[dict]]:
        thermos, sensors = [], []
        for node in self.zclient.driver.controller.nodes.values():
            kind = self._kind(node)
            if kind not in ("thermostat", "leak", "contact"):
                continue
            status = getattr(node.status, "name", str(node.status)).lower()
            battery = next((v.value for v in node.values.values() if v.command_class == CC_BATTERY and v.property_ == "level"), None)
            model = " ".join(x for x in [node.device_config.manufacturer if node.device_config else None,
                                         node.device_config.label if node.device_config else None] if x) or None
            if kind == "thermostat":
                temp = mode = heat = cool = None
                for v in node.values.values():
                    if v.command_class == CC_SENSOR_MULTILEVEL and v.property_ == "Air temperature":
                        temp = self._f(v)
                    elif v.command_class == CC_THERMOSTAT_MODE and v.property_ == "mode":
                        mode = THERMO_MODES.get(v.value, str(v.value))
                    elif v.command_class == CC_THERMOSTAT_SETPOINT and v.property_ == "setpoint":
                        if v.property_key == 1:
                            heat = self._f(v)
                        elif v.property_key == 2:
                            cool = self._f(v)
                thermos.append({"node_id": node.node_id, "model": model, "temp": temp, "mode": mode, "heat": heat,
                                "cool": cool, "battery": battery, "online": status != "dead", **self._stats(node)})
            else:
                sensors.append({"node_id": node.node_id, "kind": kind, "battery": battery, "online": status != "dead", **self._stats(node)})
        return thermos, sensors

    # ------------------------------------------------------------------ updates (Home Assistant, add-ons, stick, device firmware)
    def _updates_report(self) -> list[dict]:
        """Every update Home Assistant knows about on this hub, so the server can roll them out safely."""
        from homeassistant.helpers import device_registry as dr, entity_registry as er
        ereg, dreg = er.async_get(self.hass), dr.async_get(self.hass)
        try:
            own = self.zclient.driver.controller.own_node_id
        except Exception:  # noqa: BLE001
            own = 1
        out = []
        for st in self.hass.states.async_all("update"):
            a, eid = st.attributes, st.entity_id
            ent = ereg.async_get(eid)
            plat = ent.platform if ent else ""
            node_id = None
            if plat == "hassio":
                kind = ("core" if "home_assistant_core" in eid else "os" if "operating_system" in eid
                        else "supervisor" if "supervisor" in eid else "addon")
            elif plat == "zwave_js":
                dev = dreg.async_get(ent.device_id) if ent and ent.device_id else None
                for dom, ident in (dev.identifiers if dev else []):
                    if dom == "zwave_js" and "-" in ident:
                        try:
                            node_id = int(ident.split("-")[1])
                        except ValueError:
                            pass
                kind = "stick" if node_id == own else "device"
            else:
                kind = "other"
            out.append({"entity": eid, "kind": kind, "node_id": node_id,
                        "title": a.get("title") or a.get("friendly_name") or eid,
                        "installed": a.get("installed_version"), "latest": a.get("latest_version"),
                        "busy": bool(a.get("in_progress"))})
        return out

    async def _install_update(self, entity: str, to: str | None, by: str, cmd_id=None) -> None:
        """Start one update. Home Assistant takes a backup first when it can; the hub may restart partway through."""
        st = self.hass.states.get(entity)
        if not st:
            if cmd_id:
                self.cmd_results.append({"id": cmd_id, "ok": False, "result": {"msg": "that update is gone"}})
            return
        latest = st.attributes.get("latest_version")
        if to and latest != to:          # a newer one appeared - the server will plan it on the next sync
            if cmd_id:
                self.cmd_results.append({"id": cmd_id, "ok": False, "result": {"msg": f"now {latest} - refresh and try again"}})
            return
        if self.updating or self.including or self.excluding:
            if cmd_id:
                self.cmd_results.append({"id": cmd_id, "ok": False, "result": {"msg": "hub is busy - try again in a few minutes"}})
            return
        self.updating = entity
        data = {"entity_id": entity}
        if int(st.attributes.get("supported_features") or 0) & 8:     # UpdateEntityFeature.BACKUP
            data["backup"] = True
        self.update_results.append({"entity": entity, "to": latest, "started": True, "by": by})
        if cmd_id:
            self.cmd_results.append({"id": cmd_id, "ok": True, "result": {"msg": f"installing {latest} - the hub may restart"}})
        await self._sync_once_results_only()       # tell the server before a restart can cut us off

        async def go():
            try:
                await self.hass.services.async_call("update", "install", data, blocking=True)
            except Exception as e:  # noqa: BLE001
                self.update_results.append({"entity": entity, "to": latest, "ok": False, "err": str(e)[:200]})
                self._wake.set()
            finally:
                self.updating = None
        self._tasks.append(asyncio.create_task(go()))

    async def _climate(self, node, args: dict):
        """set mode and setpoints (args in F; converted if the thermostat works in C)"""
        mode = args.get("mode")
        for v in node.values.values():
            if v.command_class == CC_THERMOSTAT_MODE and v.property_ == "mode" and mode in THERMO_MODE_IDS:
                await node.async_set_value(v, THERMO_MODE_IDS[mode])
        for key, want in ((1, args.get("heat")), (2, args.get("cool"))):
            if want is None:
                continue
            for v in node.values.values():
                if v.command_class == CC_THERMOSTAT_SETPOINT and v.property_ == "setpoint" and v.property_key == key:
                    unit = (getattr(v.metadata, "unit", "") or "").upper()
                    val = round((float(want) - 32) * 5 / 9, 1) if "C" in unit and "F" not in unit else float(want)
                    await node.async_set_value(v, val)

    async def _govern(self, node) -> None:
        g = self.governor or {}
        if not g or node.node_id not in (g.get("managed") or []):
            return
        await asyncio.sleep(3)          # let the thermostat settle (guests tap the arrows several times)
        for v in node.values.values():
            if v.command_class != CC_THERMOSTAT_SETPOINT or v.property_ != "setpoint" or v.value is None:
                continue
            f = self._f(v)
            want = None
            if v.property_key == 1:          # heating
                if g.get("heat_max") is not None and f > g["heat_max"]:
                    want = g["heat_max"]
                elif g.get("heat_min") is not None and f < g["heat_min"]:
                    want = g["heat_min"]
            elif v.property_key == 2:        # cooling
                if g.get("cool_min") is not None and f < g["cool_min"]:
                    want = g["cool_min"]
            if want is None:
                continue
            unit = (getattr(v.metadata, "unit", "") or "").upper()
            val = round((want - 32) * 5 / 9, 1) if "C" in unit and "F" not in unit else want
            try:
                async with self._zlock:
                    await node.async_set_value(v, val)
                self.events.append({"at": _now(), "node_id": node.node_id, "kind": "governor",
                                    "detail": {"tried": f, "set_to": want, "which": "heat" if v.property_key == 1 else "cool"}})
                self._wake.set()
            except Exception as e:  # noqa: BLE001
                _LOG.warning("governor node %s: %s", node.node_id, e)

    async def _sync_once_results_only(self) -> None:
        try:
            cr, ur = self.cmd_results[:], self.update_results[:]
            await self._api("sync", {"payload": {"cmd_results": cr, "update_results": ur}})
            self.cmd_results = self.cmd_results[len(cr):]
            self.update_results = self.update_results[len(ur):]
        except Exception:  # noqa: BLE001
            pass

    async def _sync_once(self) -> None:
        events, results, cmd_results, audits = self.events[:], list(self.results.values()), self.cmd_results[:], self.audits[:]
        update_results = self.update_results[:]
        try:
            updates = self._updates_report()
        except Exception as e:  # noqa: BLE001
            _LOG.warning("update report: %s", e)
            updates = None
        thermos, sensors = self._devices_report()
        payload = {
            "status": {**self._hub_info(), "last_audit": self.last_audit, "zwave": "ok"},
            "locks": self._locks_report(), "thermostats": thermos, "sensors": sensors, "events": events, "results": results,
            "cmd_results": cmd_results, "audits": audits, "update_results": update_results,
        }
        if updates is not None:
            payload["updates"] = updates
        res = await self._api("sync", {"payload": payload})
        # sent: drop what we sent
        self.events = self.events[len(events):]
        for r in results:
            self.results.pop(r["id"], None)
        self.cmd_results = self.cmd_results[len(cmd_results):]
        self.audits = self.audits[len(audits):]
        self.update_results = self.update_results[len(update_results):]
        self.last_ok = time.time()
        if res.get("realtime"):
            self.realtime = res["realtime"]
        await self._maybe_update(res.get("latest") or {})

        if not res.get("claimed"):
            self.pair_code = res.get("pair_code")
            self._set_state(f"waiting to be added to a home (code {self.pair_code})")
            return
        if self.pair_code:
            persistent_notification.async_dismiss(self.hass, "moose_locks_pair")
            self.pair_code = None
        self.property_id = res.get("property_id")
        self.lock_names = {x["node_id"]: x["name"] for x in res.get("locks", [])}
        first = not self.governor
        self.governor = res.get("governor") or {}
        if first and self.governor:     # catch anything set past the limits while we were away
            for node in self.zclient.driver.controller.nodes.values():
                if self._kind(node) == "thermostat":
                    asyncio.create_task(self._govern(node))
        self._set_state("online")

        for cmd in res.get("commands", []):
            await self._command(cmd)
        if res.get("audit_due") or self._audit_soon:
            self._audit_soon = False
            await self._audit(wipe_all=False)
        await self._codes(res.get("assignments", []))
        for u in (res.get("install_updates") or [])[:1]:      # quiet window, test hub went first - the server decided
            await self._install_update(u.get("entity"), u.get("to"), "auto")
        if self.results or self.cmd_results or self.audits or self.update_results:
            self._wake.set()       # report right away instead of in 30 s

    # ------------------------------------------------------------------ keeps itself up to date
    async def _maybe_update(self, latest: dict) -> None:
        """A newer Moose Locks is published -> download it now, restart Home Assistant at 3 am (codes stay on the locks)."""
        want, url = latest.get("version"), latest.get("url")
        if not want or not url or getattr(self, "_staged", None) == want:
            return
        ver = lambda v: tuple(int(x) for x in str(v).split(".") if x.isdigit())
        if ver(want) <= ver(VERSION):
            return
        try:
            async with self.session.get(url, timeout=aiohttp.ClientTimeout(total=60)) as r:
                data = await r.read()
            def install():
                import io, os, zipfile
                here = os.path.dirname(os.path.abspath(__file__))
                with zipfile.ZipFile(io.BytesIO(data)) as z:
                    for name in z.namelist():
                        if not name.startswith("custom_components/moose_locks/") or name.endswith("/"):
                            continue
                        dest = os.path.join(here, name[len("custom_components/moose_locks/"):])
                        os.makedirs(os.path.dirname(dest), exist_ok=True)
                        with open(dest, "wb") as f:
                            f.write(z.read(name))
            await self.hass.async_add_executor_job(install)
            self._staged = want
            self.events.append({"at": _now(), "node_id": None, "kind": "hub_update_staged", "detail": {"from": VERSION, "to": want}})
            self._tasks.append(asyncio.create_task(self._restart_at_night()))
        except Exception as e:  # noqa: BLE001
            _LOG.warning("Moose Locks update %s failed: %s", want, e)

    async def _restart_at_night(self) -> None:
        from homeassistant.util import dt as dt_util
        while True:
            now = dt_util.now()
            if now.hour == 3 and not self.including and not self.excluding:
                await self.hass.services.async_call("homeassistant", "restart", {}, blocking=False)
                return
            await asyncio.sleep(600)

    # ------------------------------------------------------------------ commands
    def _node(self, node_id):
        return self.zclient.driver.controller.nodes.get(node_id) if node_id is not None else None

    async def _set_lock(self, node, locked: bool):
        for v in node.values.values():
            if v.command_class == CC_DOOR_LOCK and v.property_ == "targetMode":
                return await node.async_set_value(v, 255 if locked else 0)
        for v in node.values.values():
            if v.command_class == CC_LOCK and v.property_ == "locked":
                return await node.async_set_value(v, locked)
        raise RuntimeError("this lock has no lock/unlock control")

    async def _command(self, cmd: dict) -> None:
        args = cmd.get("args") or {}
        kind, cid, node = cmd["kind"], cmd["id"], self._node(cmd.get("node_id") or args.get("node"))
        ctl = self.zclient.driver.controller
        try:
            if kind in ("unlock", "lock"):
                if not node:
                    raise RuntimeError("lock not found on this hub")
                async with self._zlock:
                    res = await self._set_lock(node, kind == "lock")
                ok = res is None or getattr(res, "success", True)
                self.cmd_results.append({"id": cid, "ok": bool(ok), "result": {"status": str(getattr(res, "status", ""))}})
                if ok:
                    self.events.append({"at": _now(), "node_id": node.node_id, "kind": "remote_" + kind})
            elif kind == "ping":
                if not node:
                    raise RuntimeError("device not found on this hub")
                async with self._zlock:
                    t0 = time.time(); alive = await node.async_ping()
                self.cmd_results.append({"id": cid, "ok": bool(alive), "result": {"msg": f"answered in {int((time.time()-t0)*1000)} ms" if alive else "no answer", **self._stats(node)}})
            elif kind == "heal":
                await ctl.async_begin_rebuilding_routes()
                self.cmd_results.append({"id": cid, "ok": True, "result": {"msg": "rebuilding routes - takes a few minutes"}})
            elif kind == "restart":
                self.cmd_results.append({"id": cid, "ok": True, "result": {"msg": "restarting the hub"}})
                await self._sync_once_results_only()
                await self.hass.services.async_call("homeassistant", "restart", {}, blocking=False)
            elif kind == "update":
                await self._install_update(args.get("entity"), args.get("to"), args.get("by") or "admin", cid)
            elif kind == "climate":
                if not node:
                    raise RuntimeError("thermostat not found on this hub")
                async with self._zlock:
                    await self._climate(node, args)
                self.cmd_results.append({"id": cid, "ok": True, "result": {"set": args}})
            elif kind == "include":
                if self.including:
                    await ctl.async_stop_inclusion()
                self.including = {"pin": str(args.get("pin") or "").strip(), "cmd": cid}
                await ctl.async_begin_inclusion(InclusionStrategy.DEFAULT)
                # result comes from the node added / inclusion failed events
            elif kind == "exclude":
                self.excluding = {"cmd": cid}
                await ctl.async_begin_exclusion()
            elif kind == "stop":
                if self.including:
                    await ctl.async_stop_inclusion()
                if self.excluding:
                    await ctl.async_stop_exclusion()
                self.cmd_results.append({"id": cid, "ok": True, "result": {"msg": "stopped"}})
            elif kind == "wipe":
                await self._audit(wipe_all=True, node_only=node.node_id if node else None)
                self.cmd_results.append({"id": cid, "ok": True, "result": {"msg": "old codes found - clearing them now"}})
            elif kind == "audit":
                await self._audit(wipe_all=False, node_only=node.node_id if node else None)
                self.cmd_results.append({"id": cid, "ok": True, "result": {"msg": "read back"}})
            else:   # refresh / test code: the plan already holds it, nothing extra to do
                self.cmd_results.append({"id": cid, "ok": True, "result": {}})
        except Exception as e:  # noqa: BLE001
            self.cmd_results.append({"id": cid, "ok": False, "result": {"msg": str(e)[:200]}})
            if kind == "include":
                self.including = None
            if kind == "exclude":
                self.excluding = None

    # ------------------------------------------------------------------ codes
    @staticmethod
    def _masked(code) -> bool:
        return code is None or str(code).strip("*").strip() == ""

    async def _codes(self, assignments: list[dict]) -> None:
        now = time.time()
        for a in assignments:
            aid = a["id"]
            todo = (a["wanted"] and a["state"] in ("pending", "failed")) or (not a["wanted"] and a["state"] == "clearing")
            if not todo or aid in self.results:
                continue
            last, tries = self.attempts.get(aid, (0, a.get("tries") or 0))
            if now - last < min(15 * (2 ** min(tries, 7)), MAX_BACKOFF) and tries:
                continue
            node = self._node(a["node_id"])
            if not node:
                self.results[aid] = {"id": aid, "state": "failed", "err": "lock not on this hub"}
                continue
            self.attempts[aid] = (now, tries + 1)
            try:
                async with self._zlock:
                    if a["wanted"]:
                        await set_usercode(node, a["slot"], str(a["code"]))
                        await asyncio.sleep(2)
                        back = await get_usercode_from_node(node, a["slot"])
                        good = back.get("in_use") and (self._masked(back.get("usercode")) or str(back.get("usercode")) == str(a["code"]))
                        err = None if good else f"lock reads back {'in use' if back.get('in_use') else 'empty'}"
                        if good and a.get("sched"):
                            sres = await self._schedule(node, a["slot"], a["sched"])
                            if sres == "unsupported":
                                # never leave an early code working without its window: take it off, server switches timing
                                await clear_usercode(node, a["slot"])
                                good, err = False, "no_schedule"
                            elif sres != "ok":
                                good, err = False, f"schedule: {sres}"
                        self.results[aid] = {"id": aid, "state": "verified" if good else "failed", "err": err}
                    else:
                        await clear_usercode(node, a["slot"])
                        await asyncio.sleep(2)
                        back = await get_usercode_from_node(node, a["slot"])
                        good = not back.get("in_use")
                        self.results[aid] = {"id": aid, "state": "cleared" if good else "failed",
                                             "err": None if good else "lock still holds the code"}
            except Exception as e:  # noqa: BLE001
                self.results[aid] = {"id": aid, "state": "failed", "err": str(e)[:200]}
            await asyncio.sleep(0.5)

    # ------------------------------------------------------------------ time windows the lock enforces itself
    async def _clock(self, node) -> None:
        """Once a day per lock: set its time zone offset (handles daylight saving) and fix its clock if it drifted."""
        from homeassistant.util import dt as dt_util
        today = dt_util.now().date().isoformat()
        if self.clock_checked.get(node.node_id) == today:
            return
        offset = int(dt_util.now().utcoffset().total_seconds() // 60)
        try:
            await node.async_invoke_cc_api(CommandClass.SCHEDULE_ENTRY_LOCK, "setTimezone",
                                           {"standardOffset": offset, "dstOffset": 0}, wait_for_result=True)
        except Exception as e:  # noqa: BLE001
            _LOG.debug("timezone node %s: %s", node.node_id, e)
        try:
            await node.async_refresh_cc_values(CommandClass.TIME_PARAMETERS)
            await asyncio.sleep(3)
            v = next((x for x in node.values.values() if x.command_class == CC_TIME_PARAMETERS and x.property_ == "dateAndTime"), None)
            lock_time = dt_util.parse_datetime(str(v.value)) if v and v.value else None
            if lock_time is None or abs((lock_time - dt_util.utcnow()).total_seconds()) > 300:
                # Z-Wave JS sets the lock's clock when it (re)interviews it
                await node.async_refresh_info()
                self.events.append({"at": _now(), "node_id": node.node_id, "kind": "clock_fixed",
                                    "detail": {"lock_said": str(v.value) if v else None}})
        except Exception as e:  # noqa: BLE001
            _LOG.debug("clock node %s: %s", node.node_id, e)
        self.clock_checked[node.node_id] = today

    async def _schedule(self, node, slot: int, sched: dict) -> str:
        """Put a time window on a code slot. Returns 'ok', 'unsupported' or an error."""
        if not any(getattr(cc, "id", None) == CC_SCHEDULE_ENTRY_LOCK for cc in node.command_classes):
            return "unsupported"
        await self._clock(node)
        sid = {"userId": slot, "slotId": 1}
        try:
            if sched.get("type") == "year":
                a = datetime.fromisoformat(sched["start"]); b = datetime.fromisoformat(sched["stop"])
                await node.async_invoke_cc_api(CommandClass.SCHEDULE_ENTRY_LOCK, "setYearDaySchedule", sid, {
                    "startYear": a.year, "startMonth": a.month, "startDay": a.day, "startHour": a.hour, "startMinute": a.minute,
                    "stopYear": b.year, "stopMonth": b.month, "stopDay": b.day, "stopHour": b.hour, "stopMinute": b.minute},
                    wait_for_result=True)
            elif sched.get("type") == "daily":
                h, m = (int(x) for x in sched["start"].split(":"))
                mins = int(sched["minutes"])
                await node.async_invoke_cc_api(CommandClass.SCHEDULE_ENTRY_LOCK, "setDailyRepeatingSchedule", sid, {
                    "weekdays": sched["weekdays"], "startHour": h, "startMinute": m,
                    "durationHour": mins // 60, "durationMinute": mins % 60}, wait_for_result=True)
            else:
                return "ok"
            await node.async_invoke_cc_api(CommandClass.SCHEDULE_ENTRY_LOCK, "setEnabled", True, slot, wait_for_result=True)
            return "ok"
        except Exception as e:  # noqa: BLE001
            msg = str(e)
            if "not supported" in msg.lower() or "NotSupported" in msg:
                return "unsupported"
            return msg[:150]

    async def _audit(self, wipe_all: bool, node_only: int | None = None) -> None:
        """Read every code slot back from the locks so the server can fix drift and clear old codes."""
        for node in list(self.zclient.driver.controller.nodes.values()):
            if not self._is_lock(node) or (node_only and node.node_id != node_only):
                continue
            try:
                async with self._zlock:
                    await node.async_refresh_cc_values(CommandClass.USER_CODE)
                    await asyncio.sleep(5)
                    slots = [{"slot": s["code_slot"], "in_use": s.get("in_use"),
                              "code": None if self._masked(s.get("usercode")) else str(s.get("usercode"))}
                             for s in get_usercodes(node)]
                self.audits.append({"node_id": node.node_id, "slots": slots, "wipe_all": wipe_all})
            except Exception as e:  # noqa: BLE001
                _LOG.warning("audit node %s: %s", node.node_id, e)
        self.last_audit = _now()

    # ------------------------------------------------------------------ instant wake-ups
    async def _realtime(self) -> None:
        ref = 0
        while True:
            rt = self.realtime
            if not rt:
                await asyncio.sleep(10)
                continue
            try:
                url = f"{rt['url']}?apikey={rt['apikey']}&vsn=1.0.0"
                async with self.session.ws_connect(url, heartbeat=None, timeout=aiohttp.ClientWSTimeout(ws_close=10)) as ws:
                    ref += 1
                    await ws.send_json({"topic": f"realtime:{rt['topic']}", "event": "phx_join", "ref": str(ref),
                                        "payload": {"config": {"broadcast": {"self": False}, "presence": {"key": ""}}}})
                    last_beat = time.time()
                    while True:
                        try:
                            msg = await ws.receive(timeout=5)
                        except asyncio.TimeoutError:
                            msg = None
                        if time.time() - last_beat > 25:
                            ref += 1
                            await ws.send_json({"topic": "phoenix", "event": "heartbeat", "payload": {}, "ref": str(ref)})
                            last_beat = time.time()
                        if msg is None:
                            continue
                        if msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR, aiohttp.WSMsgType.CLOSE):
                            break
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            data = msg.json()
                            if data.get("event") == "broadcast":
                                self._wake.set()
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                _LOG.debug("realtime: %s", e)
            await asyncio.sleep(5)
