"""Moose Locks - constants. API_URL is filled in by deploy_locks.py."""
DOMAIN = "moose_locks"
VERSION = "1.0.0"
API_URL = "https://ogugdhhiajebfdwpzofp.supabase.co/functions/v1/lock-hub"

POLL_SECONDS = 30            # normal check-in; a "wake" ping from the server makes it immediate
AUDIT_HOURS = 20             # read every code slot back about once a day
MAX_BACKOFF = 1800           # a code that keeps failing is retried at most every 30 min

# Z-Wave command classes
CC_DOOR_LOCK = 98
CC_LOCK = 76
CC_USER_CODE = 99
CC_BATTERY = 128
CC_NOTIFICATION = 113
CC_BINARY_SENSOR = 48
CC_SENSOR_MULTILEVEL = 49
CC_THERMOSTAT_MODE = 64
CC_THERMOSTAT_SETPOINT = 67
THERMO_MODES = {0: "off", 1: "heat", 2: "cool", 3: "auto"}
THERMO_MODE_IDS = {v: k for k, v in THERMO_MODES.items()}

# Access Control notification (type 6) events -> our event kinds
ACCESS_EVENTS = {
    1: "lock_manual", 2: "unlock_manual", 3: "lock_remote", 4: "unlock_remote",
    5: "lock_keypad", 6: "unlock_code", 9: "lock_auto", 11: "jammed",
    12: "codes_cleared", 13: "code_deleted", 14: "code_added", 15: "code_duplicate",
    16: "keypad_off", 17: "keypad_busy", 19: "keypad_limit",
    22: "door_open", 23: "door_closed",
}
WATER_EVENTS = {1: "leak", 2: "leak", 0: "leak_clear"}
