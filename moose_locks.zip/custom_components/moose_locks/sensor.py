"""One status sensor so anyone looking at the hub can see if it's connected to Moose."""
from __future__ import annotations

from homeassistant.components.sensor import SensorEntity
from homeassistant.core import callback
from homeassistant.helpers.dispatcher import async_dispatcher_connect

from .const import DOMAIN
from .hub import SIGNAL, MooseHub


async def async_setup_entry(hass, entry, async_add_entities):
    async_add_entities([MooseStatus(hass.data[DOMAIN][entry.entry_id], entry)])


class MooseStatus(SensorEntity):
    _attr_has_entity_name = True
    _attr_name = "Moose status"
    _attr_icon = "mdi:lock-smart"
    _attr_should_poll = False

    def __init__(self, hub: MooseHub, entry) -> None:
        self.hub = hub
        self._attr_unique_id = f"{entry.entry_id}_status"

    async def async_added_to_hass(self) -> None:
        self.async_on_remove(async_dispatcher_connect(self.hass, SIGNAL, self._update))

    @callback
    def _update(self) -> None:
        self.async_write_ha_state()

    @property
    def native_value(self):
        return self.hub.state[:250]

    @property
    def extra_state_attributes(self):
        return {"pair_code": self.hub.pair_code, "home": self.hub.property_id,
                "locks": self.hub.lock_names, "last_audit": self.hub.last_audit}
